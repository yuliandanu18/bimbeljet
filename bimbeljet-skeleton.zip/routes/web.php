<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{LeadController, LeadFollowupController, PackageController, ClassController, ClassScheduleController, StudentController, EnrollmentController, InvoiceController, PaymentController, CalendarController};

Route::middleware(['auth'])->group(function () {
    Route::view('/', 'dashboard')->name('dashboard');

    Route::resource('leads', LeadController::class);
    Route::post('leads/{lead}/followups', [LeadFollowupController::class, 'store'])->name('leads.followups.store');
    Route::post('leads/{lead}/convert', [LeadController::class, 'convertToEnrollment'])->name('leads.convert');

    Route::resource('packages', PackageController::class);
    Route::resource('classes', ClassController::class);
    Route::post('classes/{class}/schedules', [ClassScheduleController::class,'store'])->name('classes.schedules.store');

    Route::resource('students', StudentController::class);
    Route::resource('enrollments', EnrollmentController::class);

    Route::resource('invoices', InvoiceController::class)->only(['index','show']);
    Route::post('invoices/{invoice}/pay', [PaymentController::class,'store'])->name('invoices.pay');

    Route::get('calendar', [CalendarController::class,'index'])->name('calendar');
});
