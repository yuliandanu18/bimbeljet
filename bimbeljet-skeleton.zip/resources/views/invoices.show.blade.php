<x-layouts.app :title="'Invoice #'.$invoice->id">
  <x-card class="space-y-2">
    <div class="font-semibold">Invoice #{{ $invoice->id }}</div>
    <div>Jatuh tempo: {{ $invoice->due_date->format('d M Y') }}</div>
    <div>Status: {{ strtoupper($invoice->status) }}</div>
    <div>Jumlah: Rp{{ number_format($invoice->amount,0,',','.') }}</div>
  </x-card>

  <x-card class="mt-4">
    <form method="post" action="{{ route('invoices.pay',$invoice) }}" class="flex gap-2 items-end">
      @csrf
      <div>
        <label class="block text-sm">Metode</label>
        <select name="method" class="rounded-xl border-gray-300">
          <option>cash</option><option>transfer</option><option>gateway</option>
        </select>
      </div>
      <div>
        <label class="block text-sm">Jumlah (Rp)</label>
        <input name="amount" type="number" class="rounded-xl border-gray-300" required />
      </div>
      <div>
        <label class="block text-sm">Ref</label>
        <input name="ref" class="rounded-xl border-gray-300" />
      </div>
      <button class="px-3 py-2 rounded-xl bg-black text-white">Bayar</button>
    </form>
  </x-card>
</x-layouts.app>
