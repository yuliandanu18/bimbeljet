<x-layouts.app title="Kalender">
  <x-card>
    <div class="text-sm text-gray-600">Placeholder kalender mingguan. Implementasi grid dapat ditambahkan.</div>
  </x-card>
</x-layouts.app>
