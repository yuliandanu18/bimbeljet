<div {{ $attributes->merge(['class'=>'rounded-2xl border bg-white p-4 shadow-sm']) }}>
  {{ $slot }}
</div>
