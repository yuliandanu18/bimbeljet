# BimbelJet – Laravel + Tailwind Skeleton

Ini adalah *addon skeleton* untuk di-merge ke **Laravel 11** bersih (mis. `composer create-project laravel/laravel bimbeljet`). 
Skeleton ini menyediakan: routes, controller, model, migrasi inti, Blade layout, komponen UI, dan contoh modul Leads.

## Cara Pakai (5 menit)
1. Buat project Laravel baru:
   ```bash
   composer create-project laravel/laravel bimbeljet
   cd bimbeljet
   ```
2. **Ekstrak ZIP** ini ke root project dan izinkan overwrite file yang sama (mis. `routes/web.php`, dll).
3. Install Breeze (opsional) dan Tailwind:
   ```bash
   composer require laravel/breeze --dev
   php artisan breeze:install blade
   npm install
   npm install -D tailwindcss postcss autoprefixer alpinejs @tailwindcss/forms
   npx tailwindcss init -p
   ```
4. Salin konfigurasi `tailwind.config.js`, `resources/css/app.css`, dan `resources/js/app.js` dari paket ini.
5. Migrasi DB:
   ```bash
   php artisan migrate
   ```
6. Jalankan dev server:
   ```bash
   php artisan serve
   npm run dev
   ```

> Modul contoh yang aktif: Leads (index/create/show), Packages, Classes (sebagian), Enrollment (sebagian), Invoices (sebagian). 
> Lanjutkan pengembangan sesuai blueprint.

## Akun & RBAC
- Gunakan Breeze untuk register/login. Role bisa diset manual di DB (kolom `role` pada tabel `users`).

## Catatan
- Ini bukan full SIM sekolah; fokus funnel bimbel: lead → trial → enrollment → invoice.
- Notifikasi WA dan gateway pembayaran masih stub.

Lisensi: MIT
