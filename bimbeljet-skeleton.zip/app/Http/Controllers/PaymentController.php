<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\{Invoice, Payment};

class PaymentController extends Controller {
  public function store(Request $r, Invoice $invoice){
    $data = $r->validate(['method'=>'required|in:cash,transfer,gateway','amount'=>'required|integer','ref'=>'nullable']);
    $payment = $invoice->payments()->create($data + ['paid_at'=>now()]);
    // Update status sederhana
    $total = $invoice->payments()->sum('amount');
    $invoice->status = $total >= $invoice->amount ? 'paid' : 'partial';
    $invoice->save();
    return back()->with('ok','Pembayaran dicatat');
  }
}
