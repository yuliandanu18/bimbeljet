<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('packages', function(Blueprint $t){
      $t->id();
      $t->string('name');
      $t->string('subject');
      $t->unsignedInteger('meetings');
      $t->unsignedInteger('minutes_per_meeting');
      $t->bigInteger('price');
      $t->boolean('allow_installment')->default(false);
      $t->foreignId('branch_id')->constrained('branches');
      $t->timestamps();
    });
    Schema::create('students', function(Blueprint $t){
      $t->id();
      $t->foreignId('user_id')->nullable()->constrained('users');
      $t->string('name')->nullable();
      $t->string('phone')->nullable();
      $t->string('parent_contact')->nullable();
      $t->string('school')->nullable();
      $t->string('grade')->nullable();
      $t->text('notes')->nullable();
      $t->timestamps();
    });
    Schema::create('tutors', function(Blueprint $t){
      $t->id();
      $t->foreignId('user_id')->nullable()->constrained('users');
      $t->json('skills')->nullable();
      $t->integer('hourly_rate')->default(0);
      $t->boolean('active')->default(true);
      $t->timestamps();
    });
  }
  public function down(): void {
    Schema::dropIfExists('tutors');
    Schema::dropIfExists('students');
    Schema::dropIfExists('packages');
  }
};
