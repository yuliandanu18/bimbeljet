<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::create('classes', function (Blueprint $t) {
      $t->id();
      $t->string('code')->unique();
      $t->string('name');
      $t->enum('type',['regular','private']);
      $t->string('subject');
      $t->unsignedInteger('capacity')->default(5);
      $t->foreignId('branch_id')->constrained('branches');
      $t->string('room')->nullable();
      $t->string('online_link')->nullable();
      $t->foreignId('package_id')->nullable()->constrained('packages');
      $t->foreignId('tutor_id')->nullable()->constrained('tutors');
      $t->date('start_date');
      $t->softDeletes();
      $t->timestamps();
    });
  }
  public function down(): void { Schema::dropIfExists('classes'); }
};
