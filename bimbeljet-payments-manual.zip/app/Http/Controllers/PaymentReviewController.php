<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\{Payment, Invoice};

class PaymentReviewController extends Controller
{
    public function index(){
        $pending = Payment::with('invoice')->where('status','pending')->latest()->paginate(20);
        $recent = Payment::with('invoice')->whereIn('status',['received','rejected'])->latest()->limit(20)->get();
        return view('payments.review.index', compact('pending','recent'));
    }

    public function show(Payment $payment){
        $payment->load('invoice');
        return view('payments.review.show', compact('payment'));
    }

    public function updateStatus(Request $r, Payment $payment){
        $data = $r->validate([
            'action'=>'required|in:received,rejected,pending,cancelled',
            'notes'=>'nullable|string'
        ]);
        $payment->status = $data['action'];
        $payment->verified_by = optional($r->user())->id;
        $payment->verified_at = now();
        if($r->filled('notes')) $payment->notes = $r->string('notes');
        $payment->save();

        // Recompute invoice status
        $invoice = $payment->invoice;
        $receivedTotal = $invoice->payments()->where('status','received')->sum('amount');
        if($receivedTotal >= $invoice->amount){
            $invoice->status = 'paid';
        } elseif($receivedTotal > 0){
            $invoice->status = 'partial';
        } else {
            $invoice->status = 'unpaid';
        }
        $invoice->save();

        return back()->with('ok','Status pembayaran diperbarui');
    }
}
